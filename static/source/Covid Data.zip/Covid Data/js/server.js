const url = "https://local-ride-3671d-default-rtdb.asia-southeast1.firebasedatabase.app/https://local-ride-3671d-default-rtdb.asia-southeast1.firebasedatabase.app/"

let variable = {
    'Name' : "Ankan Saha",
    'Roll' : "67",
    'Semester' : "1st Semester" 
}
document.getElementById('btn').addEventListener('click', ()=>{
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAyJi3CRD9iQMy-b-udHCy27A240Ic0Q8I",
  authDomain: "local-ride-3671d.firebaseapp.com",
  databaseURL: "https://local-ride-3671d-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "local-ride-3671d",
  storageBucket: "local-ride-3671d.appspot.com",
  messagingSenderId: "448773125708",
  appId: "1:448773125708:web:4c297a8498e5d0489d66e9",
  measurementId: "G-403D28C5ZW"
};
if (!firebase.apps.length) {
  firebase.initializeApp(config);
}
this.database = firebase.database();


let userRef = this.database.ref('users/' + userId);
userRef.child(
'mike').set(variable)
})