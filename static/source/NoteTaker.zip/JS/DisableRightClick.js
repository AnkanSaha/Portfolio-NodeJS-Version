// Disable Right Click
// document.addEventListener("contextmenu", (A)=>{
//     A.preventDefault();
//     alert("Don't Try To Be Oversmart")
// }, false);