// version Details


// Version Value

Value = "5.1 (stable)"
let version = document.getElementById('version')
version.innerText = "Current Version"+" : "+Value
