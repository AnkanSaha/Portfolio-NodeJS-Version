const Pricing = document.getElementById('getstarted');
Pricing.addEventListener('click', ()=>{
    window.location.href = "/html/pricing.html"
})
document.getElementById('submited').addEventListener('click', ()=>{
    let massaged = document.getElementById('message').value 
    let named = document.getElementById('name').value
    let emailed = document.getElementById('email').value
    if(emailed !="" && named !="" && massaged !=""){
            alert('Thank You for contacting us...')
    }
    else{
        alert('Please fill the form')
    }
})

// Disable Right Click
document.addEventListener('contextmenu', (m)=>{
    m.preventDefault();
}, false);