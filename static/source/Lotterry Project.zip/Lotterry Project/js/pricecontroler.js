const RS20 = document.getElementById('RS20')
RS20.addEventListener('click', ()=>{
    console.log(RS20)
    
    window.location.href = "index.html"
})