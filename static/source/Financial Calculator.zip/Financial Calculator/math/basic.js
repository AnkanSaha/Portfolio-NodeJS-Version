const Basic = document.getElementById('basicCalculate')
Basic.addEventListener('click', ()=>{
    let F = parseInt(document.getElementById('FirstNumber').value)
    let S = parseInt(document.getElementById('secondnumber').value)
    let M = document.getElementById('method').value
    console.log(F, S, M)
        // Display Settings
        document.getElementById('basic').style.display = 'none'
        document.getElementById('loading').innerHTML = `<img id="lodingimg" src="/images/loading.gif" alt="">`
        document.getElementById('loading').style.display = 'flex'
        document.getElementById('subtag').innerText = "Calculating"
        
    // Empty variable declare
    var Total = 0;

  setTimeout(() => {
    if(F!= "" && S != "" && M != ""){

        if(M == "Plus"){
            var Total = F + S
            console.log(Total);
            document.getElementById('BasicTotal').innerText ="Total Plus Result : "+Total
        }
        else if(M == "Minus"){
            var Total = F - S
            console.log(Total)
            document.getElementById('BasicTotal').innerText ="Total Minus Result : "+Total
        }
        else if(M == "Multiply"){
            var Total = F * S
            console.log(Total)
            document.getElementById('BasicTotal').innerText ="Total Multiply Result :"+Total
        }
        else if(M == "Divide"){
            var Total = F / S
            console.log(Total)
            document.getElementById('BasicTotal').innerText ="Total Divide Result : "+Total
        }
        // Reverse Display Settings
        document.getElementById('subtag').innerText = "Result Declared"
        document.getElementById('basicresult').style.display = 'flex'
        document.getElementById('basic').style.display = 'flex'
        document.getElementById('loading').style.display = 'none'
    }
    else{
        alert("Please Fill all Fields To Proceed")
    }
  }, 4000);
})