document.getElementById('compoundcalculate').addEventListener('click', ()=>{
    let P = document.getElementById('PAM').value
    let R = document.getElementById('RINT').value
    let N = document.getElementById('NOY').value
    let F = document.getElementById('Frequent').value
    console.log(P, R, N, F)

    if(P != "" && R != "" && N != "" && F != ""){
        // Display Settings
        document.getElementById('loading').innerHTML = `<img id="lodingimg" src="/images/loading.gif" alt="">`
        document.getElementById('loading').style.display = 'flex'
        document.getElementById('compound').style.display = 'none'
        document.getElementById('subtag').innerText = 'Calculating'
        setTimeout(() => {
            var mt = 0;

            if(F == "Yearly"){
                mt = N*1
            }
            else if(F == "Quaterly"){
                mt = N*3
            }
            else if(F == "Monthly"){
                mt = N*12
            }
            else if(F == "Half Yearly"){
                mt = N*6
            }
            console.log(mt)
        
            var total = (P*Math.pow(1+(R/(N*100)),mt))
            var Tamount = total.toFixed(2)
            console.log("Total Amount : "+Tamount)
            var CI = Tamount-P;
            console.log("Compound Interest : "+CI)
        
            // Reverse Display Settings
            document.getElementById('subtag').innerText = 'Result Declared'
            document.getElementById('CompoundTotal').innerText ="Total Amount : "+Tamount
            document.getElementById('CompoundInterest').innerText ="Interest : "+CI.toFixed(2)
            document.getElementById('rrsult').style.display = 'flex'
            document.getElementById('loading').style.display = 'none'
            document.getElementById('compound').style.display = 'flex'
        }, 4000);
    }
    else{
        alert("Please Fill All Value")
    }

})

// var mt = 0;

// if(F == "Yearly"){
//     mt = N*1
// }
// else if(F == "Quaterly"){
//     mt = N*3
// }
// else if(F == "Monthly"){
//     mt = N*12
// }
// else if(F == "Half Yearly"){
//     mt = N*6
// }
// console.log(mt)

// var total = (P*Math.pow(1+(R/(N*100)),mt))
// var Tamount = total.toFixed(2)
// console.log("Total Amount : "+Tamount)
// var CI = Tamount-P;
// console.log("Compound Interest : "+CI)

// document.getElementById('CompoundTotal').innerText ="Total Amount : "+Tamount
// document.getElementById('CompoundInterest').innerText ="Interest : "+CI.toFixed(2)

