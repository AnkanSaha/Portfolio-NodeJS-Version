// const Home = document.getElementById('home')
// Home.addEventListener('click', ()=>{
//     window.location.href = "index.html"
// })

// Disable Right Click
document.addEventListener('contextmenu', (e)=>{
    e.preventDefault();
}, false)