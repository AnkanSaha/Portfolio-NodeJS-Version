function wishing(){
    // Time Generator
    const ctimer = new Date();
    let hour = ctimer.getHours();
    let minutes = ctimer.getMinutes();
    let seconds = ctimer.getSeconds();
    let divider
    
    // Placing AM/PM System
    if(hour > 12){
        divider = "PM"
    }
    else if(hour == 12){
        divider = "PM"
    }
    else if(hour < 12){
        divider = "AM"
    }
    
    // placing 0 in front of minutes
    if(minutes < 9){
        minutes = "0"+minutes
    }
    else if(minutes == 9){
        minutes = "0"+minutes
    }
    
    // Placing 0 in Front of seconds
    if(seconds < 9){
        seconds = "0"+seconds
    }
    else if(seconds == 9){
        seconds = "0"+seconds
    }
    
    // Correction at After PM
    if(hour == 13){
        hour = "01"
    }
    else if(hour == 14){
        hour = "02"
    }
    else if(hour == 15){
        hour = "03"
    }
    else if(hour == 16){
        hour = "04"
    }
    else if(hour == 17){
        hour = "05"
    }
    else if(hour == 18){
        hour = "06"
    }
    else if(hour == 19){
        hour = "07"
    }
    else if(hour == 20){
        hour = "08"
    }
    else if(hour == 21){
        hour = "09"
    }
    else if(hour == 22){
        hour = "10"
    }
    else if(hour == 23){
        hour = "11"
    }
    
    let finaltime = hour+" : "+ minutes+" : "+ seconds+" "+ divider

    localStorage.setItem('Current Time', finaltime);
    let timeshow = localStorage.getItem('Current Time');
    console.log(timeshow)


    let ctime = new Date()
    let hours = ctime.getHours()
    console.log(hours)
    let user = localStorage.getItem('currentuser');

    if(hours > 0 && hours < 5){
        document.getElementById('wishes').innerText = 'Good Night : '+user+' ( '+timeshow+' ) '
    }
    else if(hours > 4 && hours < 11){
        document.getElementById('wishes').innerText = 'Good Morning : '+user+' ( '+timeshow+' ) '
    }
    else if(hours > 10 && hours < 15){
        document.getElementById('wishes').innerText = 'Good Noon : '+user+' ( '+timeshow+' ) '
    }
    else if(hours > 14 && hours < 17){
        document.getElementById('wishes').innerText = 'Good Afternoon : '+user+' ( '+timeshow+' ) '
    }
    else if(hours > 16 && hours < 20){
        document.getElementById('wishes').innerText = 'Good Evening : '+user+' ( '+timeshow+' ) '
    }
    else if( hours > 19 && hours < 24){
        document.getElementById('wishes').innerText = 'Good Night : '+user+' ( '+timeshow+' ) '
    }
}

setInterval(wishing, 100)