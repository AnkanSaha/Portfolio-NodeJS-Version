document.getElementById('sendmass').addEventListener('click', ()=>{
    var name = document.getElementById('name').value
    var email = document.getElementById('email').value
    var massage = document.getElementById('message').value

    if(name.length < 2 && email.length < 3 && massage.length < 2){
        alert('Fields can not be blank')
    }
    else if(name.length > 2 && email.length > 3 && massage.length > 2){
        alert('Massage Sent Successfully')
    }
})