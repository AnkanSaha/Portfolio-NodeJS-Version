let logout = document.getElementById('logout');
logout.addEventListener('click', ()=>{
    var userdata = localStorage.getItem('currentuser')
    console.log(userdata);

    let confirmlogout = confirm('Are You Sure to Delete This Account ?')

    if(confirmlogout == false){
        alert("Thank You "+userdata+" Please Continue Your Service");
    }
    else if(confirmlogout == true){
        localStorage.removeItem('currentuser')
    }
})