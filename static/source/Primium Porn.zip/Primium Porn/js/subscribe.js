document.getElementById('subscribe').addEventListener('click', ()=>{
    let username = localStorage.getItem('currentuser');

    if(username == null){
        alert('Please Complete Registration & Then Buy our Plans');
    }
    else if(username != null){
        alert('Dear '+username+' You will be Redirected To Plans Section, Please Complete Your Payment')
        window.open('https://rzp.io/i/LE9Zs48')
    }
})