// New registration Process
let registration = document.getElementById('register');

registration.addEventListener('click', ()=>{
    let newregistration = document.getElementById('fullname').value
    let email = document.getElementById('email').value
    if(newregistration.length < 2 && email.length < 3){
        alert('Minimum 3 Chsarecter Requied To Registration')
    }
    else if(newregistration.length > 2 && email.length > 3){
        let user = localStorage.getItem('currentuser');
        console.log(user)
        if(user != null){
            alert('Already a user exist on this device : '+ user)
            document.getElementById('username').innerText = user
            document.getElementById('registrationbox').style.display = 'none'
        }
        else if(user == null){
            localStorage.setItem('currentuser', newregistration)
            localStorage.setItem('email', email)
            let newuser = localStorage.getItem('currentuser');
            alert("You are Successfully Registered : "+newuser)
            document.getElementById('username').innerText = newregistration
            document.getElementById('registrationbox').style.display = 'none'
        }
    }
 
})

// Registration Box Controller
cachedata()
setInterval(cachedata, 100);

function cachedata(){
    let users = localStorage.getItem('currentuser')
    if(users != null){
        document.getElementById('username').innerText = users
        document.getElementById('registrationbox').style.display = 'none'
        document.getElementById('registrationrequest').style.display = 'none'
        document.getElementById('wishes').style.display = ''
        document.getElementById('logout').style.display = ''
    }
    else if(users == null){
        document.getElementById('username').innerText = 'Register Now'
        document.getElementById('registrationrequest').style.display = ''
        document.getElementById('registrationbox').style.display = ''
        document.getElementById('registrationrequest').innerText = "Please Register Yourself To Use Our Website & view our most viral & primium videos"
        document.getElementById('wishes').style.display = 'none'
        document.getElementById('logout').style.display = 'none'
    }
}